
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-gray-800 text-white p-6 flex flex-col items-center justify-center">
      <h1 className="text-4xl md:text-6xl font-bold text-center mb-6">🚀 Welcome to mXai Tabhai</h1>
      <p className="text-center max-w-2xl text-lg mb-10">
        Empowering 1 Lakh content creators by 2026. Free AI tools, creator resources, and next-level guidance — all in one place.
      </p>

      <Card className="w-full max-w-xl bg-gray-900 border border-gray-700">
        <CardContent className="p-6 flex flex-col gap-4">
          <h2 className="text-2xl font-semibold">🎯 Start Your Journey</h2>
          <p>Sign up to access our free AI tools & content resources:</p>
          <Input placeholder="Enter your email" className="bg-gray-800 text-white" />
          <Button className="bg-blue-600 hover:bg-blue-700">Join the Mission</Button>
        </CardContent>
      </Card>

      <div className="mt-10 text-center">
        <h3 className="text-xl font-semibold mb-2">🔧 Tools You'll Get Access To</h3>
        <ul className="list-disc list-inside space-y-1">
          <li>Auto Thumbnail + Caption Generator</li>
          <li>Free AI Video Creation Resources</li>
          <li>Viral Content Planner</li>
          <li>Beginner to Pro Creator Guides</li>
        </ul>
      </div>
    </div>
  );
}
